import os
import json
import logging
import requests
import base64

# Setup logging
logging.basicConfig(level=logging.DEBUG)

# Constants
BASE_URL = "https://e621.net"
HEADERS = {
    "User-Agent": "MyProject/1.0 (by Username on e621)",
    "Authorization": "Basic " + base64.b64encode("username:APIKey".encode()).decode() #remeber to add username and APIKey to this line
}

def fetch_pool_name(pool_id):
    # Fetch the pool's name
    response = requests.get(
        f"{BASE_URL}/pools/{pool_id}.json",
        headers=HEADERS
    )
    response.raise_for_status()
    data = response.json()
    return data["name"]

def create_nfo_file(post, file_path):
    # Extract relevant metadata
    post_tags = ' '.join(post['tags']['general'] + post['tags']['species'] + post['tags']['character'])
    post_description = post.get('description', '')
    post_artist = ', '.join(post['tags']['artist'])
    post_sources = '\n'.join(post['sources'])

    # Create the .nfo file content
    nfo_content = f"Artist: {post_artist}\nTags: {post_tags}\nDescription: {post_description}\nSources: {post_sources}\n"

    # Write the content to the .nfo file
    with open(file_path + ".nfo", "w", encoding="utf-8") as nfo_file:
        nfo_file.write(nfo_content)

def fetch_pool_posts(pool_id):
    # Fetch posts from the pool
    response = requests.get(
        f"{BASE_URL}/posts.json",
        headers=HEADERS,
        params={"tags": f"pool:{pool_id}", "limit": 320}
    )
    response.raise_for_status()
    data = response.json()
    posts = data["posts"]

    # Check if posts are available
    if not posts:
        logging.info(f"No posts found for pool: {pool_id}.")
        return

    # Extract pool name
    pool_name = fetch_pool_name(pool_id)

    # Create a directory for the pool if it doesn't exist
    pool_directory = os.path.join("downloads", str(pool_id) + " - " + pool_name)
    os.makedirs(pool_directory, exist_ok=True)

    # Initialize a counter for page numbers
    page_counter = 1

    # Reverse the order of posts
    posts = posts[::-1]

    # Download each post
    for post in posts:
        file_url = post["file"]["url"]
        file_extension = os.path.splitext(file_url)[1]
        
        # Use the counter to name the file
        file_name = f"page_{page_counter}{file_extension}"
        file_path = os.path.join(pool_directory, file_name)

        # Check if the file already exists
        if os.path.exists(file_path):
            logging.info(f"File {file_name} already exists. Skipping download.")
            continue

        with requests.get(file_url, stream=True, headers=HEADERS) as r:
            r.raise_for_status()
            with open(file_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

        logging.info(f"Downloaded {file_name} to {pool_directory}")

        # Create the .nfo file for the post
        create_nfo_file(post, file_path)

        # Increment the counter for the next file
        page_counter += 1

if __name__ == "__main__":
    with open("pools.txt", "r") as f:
        for pool_id in f.readlines():
            fetch_pool_posts(pool_id.strip())
